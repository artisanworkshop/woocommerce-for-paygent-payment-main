using System;
using System.Security.Cryptography;
using System.Text;

class HashSample
{
    static void Main(string[] args)
    {
        String tradingId = "444444";
        String paymentType = "01,02,03";
        String fixParams = "customer_family_name";
        String id = "1000";
        String seqMerchantId = "999999";
        String paymentTermDay = "5";
        String paymentTermMin = "";
        String paymentClass = "1";
        String useCardConfNumber = "0";
        String customerId = "cust001";
        String threedsecure_ryaku = "";
        String hashKey = "abc123";

        String orgStr = tradingId
              + paymentType
              + fixParams
              + id
              + seqMerchantId
              + paymentTermDay
              + paymentTermMin
              + paymentClass
              + useCardConfNumber
              + customerId
              + threedsecure_ryaku
              + hashKey;

        byte[] byteValues = Encoding.UTF8.GetBytes(orgStr);
        SHA256 crypto = new SHA256Managed();
        byte[] hashValue = crypto.ComputeHash(byteValues);

        StringBuilder hasheStr = new StringBuilder();
        for (int i = 0; i < hashValue.Length; i++) {
            hasheStr.AppendFormat("{0:x2}", hashValue[i]);
        }

        char[] randSeeds = {'a','b','c','d','e','f','A','B','C','D','E','F','0','1','2','3','4','5','6','7','8','9'};
        Random rand = new Random();
        StringBuilder randStr = new StringBuilder();
        for(int i = 0; (i < 20 && rand.Next(10) != 0); i++) {
            randStr.Append(randSeeds[rand.Next(randSeeds.Length)]);
        }

        Console.WriteLine(hasheStr.ToString() + randStr);
    }
}
