#!/usr/bin/perl

use Digest::SHA;

$trading_id = "444444";
$payment_type = "01,02,03";
$fix_params = "customer_family_name";
$id = "1000";
$seq_merchant_id = "999999";
$payment_term_day = "5";
$payment_term_min = "";
$payment_class = "1";
$use_card_conf_number = "0";
$customer_id = "cust001";
$threedsecure_ryaku = "";
$hash_key = "abc123";

# create hash hex string
$org_str = $trading_id .
          $payment_type .
          $fix_params .
          $id .
          $seq_merchant_id .
          $payment_term_day .
          $payment_term_min .
          $payment_class .
          $use_card_conf_number .
          $customer_id .
          $threedsecure_ryaku .
          $hash_key;

$context = Digest::SHA->new("SHA-256");
$context->add($org_str);
$hash_str = $context->hexdigest;

# create random string
$rand_str = "";
@rand_char = ('a','b','c','d','e','f','A','B','C','D','E','F','0','1','2','3','4','5','6','7','8','9');
for(1..20){
  $rand_str .= $rand_char[int(rand($#rand_char))];
  if(int(rand(10)) == 1) {
    last;
  }
}

print $hash_str . $rand_str .  "\n";
