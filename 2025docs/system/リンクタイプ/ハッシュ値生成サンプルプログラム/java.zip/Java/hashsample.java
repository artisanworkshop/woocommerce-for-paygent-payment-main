import java.util.Random;
import java.security.MessageDigest;

public class hashsample {
  public static void main(String[] args) {
    String trading_id = "444444";
    String payment_type = "01,02,03";
    String fix_params = "customer_family_name";
    String id = "1000";
    String seq_merchant_id = "999999";
    String payment_term_day = "5";
    String payment_term_min = "";
    String payment_class = "1";
    String use_card_conf_number = "0";
    String customer_id = "cust001";
    String threedsecure_ryaku = "";
    String hash_key = "abc123";

    String org_str = trading_id
          + payment_type
          + fix_params
          + id
          + seq_merchant_id
          + payment_term_day
          + payment_term_min
          + payment_class
          + use_card_conf_number
          + customer_id
          + threedsecure_ryaku
          + hash_key;
    System.out.println(createHash(org_str));
  }

  private static String createHash(String str) {
    try {
      // create hash hex string
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      byte[] digest = md.digest(str.getBytes());
      String hash_str = toHex(digest);

      // create random string
      char[] rand_char = {'a','b','c','d','e','f','A','B','C','D','E','F','0','1','2','3','4','5','6','7','8','9'};
      Random rand = new Random();
      StringBuffer rand_str = new StringBuffer();
      for(int i=0; (i<20 && rand.nextInt(10) != 0); i++) {
        rand_str.append(String.valueOf(rand_char[rand.nextInt(rand_char.length)]));
      }

      return hash_str + rand_str;  
    }
    catch(Exception e){
      e.printStackTrace();
      return null;
    }
  }

  private static String toHex(byte b[]) {
    StringBuffer sb = new StringBuffer(b.length * 2);
    for (int i = 0; i < b.length; i++) {
      int data = b[i];
      sb.append(Character.forDigit((data & 0xf0) >> 4, 16));
      sb.append(Character.forDigit(data & 0x0f, 16));
    }
    return sb.toString();
  }
}
